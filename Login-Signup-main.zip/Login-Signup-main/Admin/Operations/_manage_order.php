<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php"); // Redirect to login page if not logged in
    exit();
}

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_db";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare SQL statement to select all order details
    $stmt = $conn->prepare("SELECT * FROM orders");
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - Admin Panel</title>
    <!-- Add your CSS styling -->
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: auto;
            padding: 20px;
        }
        .cart-table, .checkout-table {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: rgb(255,62,183);
            color: white;
        }
        .cart-image {
            width: 80px;
            border-radius: 5px;
        }
        .quantity-controls {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .quantity-controls button {
            background: white;
            color: black;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 3px;
            margin: 0 5px;
        }
        .btn-remove {
            background: red;
            color: white;
            border: none;
            padding: 7px 10px;
            cursor: pointer;
            border-radius: 5px;
        }
        .checkout-table {
            width: 50%;
            margin: 0 auto;
        }
        .checkout-table th {
            background:rgb(255,62,183);
            color: white;
        }
        .checkout-table td {
            text-align: left;
            padding: 10px;
        }
        .btn-checkout {
            background:rgb(255,62,183);
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
            width: 100%;
            margin-top: 10px;
        }
        .btn-checkout:hover {
            background:rgb(255,62,183);
        }
        input[type="checkbox"] {
            transform: scale(1.2);
        }  
        h2{
            padding-bottom : 20px;
            font-size: 30px;
        }
        h3{
            padding-bottom : 20px;
            font-size: 30px;
        }
        p{
            font-size: 20px;
        }
        /* Style for "Go back to shop" link */
        .back-to-shop {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #3498db;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .back-to-shop:hover {
            color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Manage Orders</h2>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Subtotal</th>
                    <th>Shipping</th>
                    <th>VAT</th>
                      <th>Phone No</th>
                    <th>Address</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= $order['order_id'] ?></td>
                        <td><?= htmlspecialchars($order['name']) ?></td>
                        <td><?= htmlspecialchars($order['email']) ?></td>
                        <td>Rs.<?= htmlspecialchars($order['subtotal']) ?></td>
                        <td>Rs.<?= htmlspecialchars($order['shipping']) ?></td>
                        <td>Rs.<?= htmlspecialchars($order['vat']) ?></td>
                        <td>Rs.<?= htmlspecialchars($order['phone_no']) ?></td>
                        <td><?= htmlspecialchars($order['address']) ?></td>
                        <td>Rs.<?= htmlspecialchars($order['total']) ?></td>
                         <td>
                            <a href="mark_accepted.php?order_id=<?= $order['order_id'] ?>">Accept</a> |
                            <a href="mark_rejected.php?order_id=<?= $order['order_id'] ?>">Reject</a>
                         </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>