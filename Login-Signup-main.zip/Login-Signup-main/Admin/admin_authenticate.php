<?php
session_start();

include './Classes/database.php';
include './Classes/fetch.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $fetch = new Fetch();
    if ($fetch->verify_admin($username, $password)) {
        $_SESSION['admin'] = true;
        header("Location: ./index.php");
        exit();
    } else {
        header("Location: ./admin_login.php?error=true");
    }
}
?>