<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <!-- CSS -->
    <style>
        body {
            font-family: sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .admin-login-section {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .admin-login-container {
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .admin-form-control {
            margin-bottom: 15px;
        }

        label {
            display: block;
            text-align: left;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            margin-top: 5px;
            font-size: 16px;
        }

        button[type="submit"] {
            background-color: #90EE90; /* Light Green */
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: #50C878; /* Darker Green */
        }

        .error-mssg {
            color: #D8000C; /* Red */
            background-color: #FFBABA;
            border: 1px solid #D8000C;
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<section class="admin-login-section">
        <div class="admin-login-container">
        <h1>Admin Login</h1>
            <form action="admin_authenticate.php" method="post">
                <div class="admin-form-control">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" required autocomplete="off">
                </div>
                <div class="admin-form-control">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" required autocomplete="off">
                </div>
                <div class="admin-form-control">
                    <button type="submit">Login</button>
                </div>
                <?php if(isset($_GET['error'])){
                        echo '<div class="error-mssg">
                            <p>Invalid Credentials</p>
                         </div>';
                    }
                 ?>
            </form>
        </div>
</section>
</body>
</html>