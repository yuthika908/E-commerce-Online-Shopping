const danger = document.querySelector('.danger');

danger.style.display = "block";

setTimeout(() => {
    danger.style.display = "none";
}, 2000);