const success = document.querySelector('.success');

success.style.display = "block";

setTimeout(() => {
    success.style.display = "none";
}, 2000);