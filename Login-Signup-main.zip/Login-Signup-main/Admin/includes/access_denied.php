<?php
    echo '<div class="error-container">
    <div class="error-logo">
        <i class="fa-solid fa-lock"></i>
    </div>
    <div class="error-title">
        <h2>Access Denied</h2>
    </div>
    <div class="error-mssg">
        <span>You don\'t have permissions to access this page.</span>
        <span>Contact an administrator to get permissions or go to the home page</span>
        <span>and browse other pages</span>
    </div>
    <div class="error-btn">
        <a href="/FashionHub/index.php">Go to Home</a>
    </div>
    </div>';
?>