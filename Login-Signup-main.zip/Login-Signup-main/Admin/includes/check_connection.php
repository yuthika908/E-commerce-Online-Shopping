<?php
    function isConnected() {
        try {
            $host = "localhost";
            $db_name = "24128447";
            $db_user = "root";
            $db_pass = "";

            $connection = new PDO("mysql:host=$host;dbname=$db_name", $db_user, $db_pass);
            $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return true;

        } catch (PDOException $e) {
            return false;
        }
    }
?>