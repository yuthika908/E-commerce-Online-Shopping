<?php
    echo '<div class="danger">
    <div class="danger-mssg">
        <span><i class="fa-solid fa-triangle-exclamation"></i> '. $_SESSION['alert_message'] .'</span>
    </div>
    <div class="danger-loading"></div>
    </div>';
?>