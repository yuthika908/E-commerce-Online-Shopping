<?php
    echo '<footer>
        <span>&copy; Copyright © Fashion Frenzy 2025 All right preserved</span>
    </footer>';
?>