<?php
    echo '<!-- Header -->
    <header>
        <div class="header-title">
            <a href="./index.php">Fashion Frenzy</a>
        </div>
        <div class="header-admin-details">
            <a href="./admin_login.php">
                                        <i class="fa-solid fa-right-from-bracket"></i>
                                        <span>Logout</span>
                                    </a>
           
        </div>
    </header>';
?>