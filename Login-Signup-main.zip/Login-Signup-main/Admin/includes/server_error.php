<?php
    echo '<div class="server-error-container">
            <h1>500</h1>
            <h2>Internal Server Error</h2>
            <span>The server encountered an internal error or misconfiguration</span>
            <span>and was unable to complete your request.</span>
        </div>';
?>