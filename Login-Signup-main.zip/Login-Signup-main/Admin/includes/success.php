<?php
    echo '<div class="success">
    <div class="success-mssg">
        <span><i class="fa-solid fa-circle-check"></i> '. $_SESSION['alert_message'] .'</span>
    </div>
    <div class="success-loading"></div>
    </div>';
?>