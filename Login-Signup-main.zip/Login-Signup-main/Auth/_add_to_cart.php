<?php
session_start();

// Include necessary files
include '../Classes/database.php';  // Make sure this path is correct
include '../Classes/fetch.php';  // Make sure this path is correct

// Check if the user is logged in and the product ID is provided
if (isset($_SESSION['user']['id']) && isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];
    $user_id = $_SESSION['user']['id'];
    $quantity = 1; // Default quantity

    $fetch = new Fetch(); // Create an instance of your Fetch class

    // Check if product is already in the cart
    if ($fetch->check_product_in_cart($product_id)) {
        // Product is already in cart, set an alert message
        $_SESSION['alert_message'] = "Product is already in your cart!";
        $_SESSION['alert_type'] = 'warning';  // or 'info'
    } else {
        // Add the product to the cart
        $db = new Database(); // Assuming Database class handles connection
        $conn = $db->connect();

        $sql = "INSERT INTO cart (product_id, user_id, quantity) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("iii", $product_id, $user_id, $quantity);  // "iii" for three integers
            if ($stmt->execute()) {
                // Set success message
                $_SESSION['alert_message'] = "Product added to cart successfully!";
                $_SESSION['alert_type'] = 'success';
            } else {
                // Set error message
                $_SESSION['alert_message'] = "Failed to add product to cart: " . $stmt->error;
                $_SESSION['alert_type'] = 'danger';
            }
            $stmt->close();
        } else {
            $_SESSION['alert_message'] = "Failed to prepare statement: " . $conn->error;
            $_SESSION['alert_type'] = 'danger';
        }

        $conn->close();
    }

} else {
    // Set error message if user is not logged in or product ID is missing
    $_SESSION['alert_message'] = "You must be logged in to add products to the cart.";
    $_SESSION['alert_type'] = 'danger';
}

// Redirect to the cart page
header("Location: ../website/cart.php");
exit();
?>