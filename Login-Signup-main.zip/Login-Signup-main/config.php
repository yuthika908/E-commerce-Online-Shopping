<?php

$conn = mysqli_connect('localhost','root','','24128447');

?>