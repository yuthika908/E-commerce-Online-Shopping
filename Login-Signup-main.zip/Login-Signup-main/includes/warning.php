<?php
    echo '<div class="warning">
    <div class="warning-mssg">
        <span><i class="fa-solid fa-triangle-exclamation"></i> You are not Logged in.</span>
    </div>
    <div class="warning-loading"></div>
    </div>';
?>