<?php
session_start();

// Database Connection
$host = "localhost";
$username = "root";
$password = "";
$database = "user_db";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Initialize cart if not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Function to calculate cart totals based on selected items
function calculateCartTotals($cart, $selectedItems) {
    $subtotal = 0;
    foreach ($selectedItems as $productId) {
        if (isset($cart[$productId])) {
            $item = $cart[$productId];
            $subtotal += $item['product_price'] * $item['qty'];
        }
    }

    $shipping = 70; // Fixed shipping cost
    $vatRate = 0.13; // 13% VAT
    $vat = $subtotal * $vatRate;
    $total = $subtotal + $shipping + $vat;

    return [
        'subtotal' => $subtotal,
        'shipping' => $shipping,
        'vat' => $vat,
        'total' => $total
    ];
}

// Handle Cart Logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_to_cart'])) {
        // Add item to cart
        $productId = $_POST['product_id'];
        $productName = $_POST['product_name'];
        $productPrice = $_POST['product_price'];
        $productImage = $_POST['product_image1'];

        if (!isset($_SESSION['cart'][$productId])) {
            $_SESSION['cart'][$productId] = [
                'product_name' => $productName,
                'product_price' => $productPrice,
                'product_image1' => $productImage,
                'qty' => 1
            ];
        } else {
            $_SESSION['cart'][$productId]['qty'] += 1;
        }
    } elseif (isset($_POST['increase_quantity'])) {
        // Increase quantity
        $productId = $_POST['increase_quantity'];
        if (isset($_SESSION['cart'][$productId])) {
            $_SESSION['cart'][$productId]['qty'] += 1;
        }
    } elseif (isset($_POST['decrease_quantity'])) {
        // Decrease quantity
        $productId = $_POST['decrease_quantity'];
        if (isset($_SESSION['cart'][$productId])) {
            if ($_SESSION['cart'][$productId]['qty'] > 1) {
                $_SESSION['cart'][$productId]['qty'] -= 1;
            } else {
                unset($_SESSION['cart'][$productId]);
            }
        }
    } elseif (isset($_POST['remove_item'])) {
        // Remove item
        $productId = $_POST['remove_item'];
        unset($_SESSION['cart'][$productId]);
    }

    // Redirect to avoid form resubmission
    header("Location: cart.php");
    exit();
}

// Initialize totals
$subtotal = 0;
$shipping = 70;
$vat = 0;
$total = 0;
$productImage = ''; // Initialize product image variable

// Calculate totals based on SELECTED items if cart is not empty
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $selectedItems = isset($_POST['selected_items']) ? $_POST['selected_items'] : array_keys($_SESSION['cart']);
    $totals = calculateCartTotals($_SESSION['cart'], $selectedItems);
    $subtotal = $totals['subtotal'];
    $vat = $totals['vat'];
    $total = $totals['total'];

    // Get product image of the first selected item (you can modify the logic here)
    if (!empty($selectedItems)) {
        $firstProductId = reset($selectedItems);
        if (isset($_SESSION['cart'][$firstProductId]['product_image1'])) {
            $productImage = $_SESSION['cart'][$firstProductId]['product_image1'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: auto;
            padding: 20px;
        }
        .cart-table, .checkout-table {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background: rgb(255,62,183);
            color: white;
        }
        .cart-image {
            width: 80px;
            border-radius: 5px;
        }
        .quantity-controls {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .quantity-controls button {
            background: white;
            color: black;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 3px;
            margin: 0 5px;
        }
        .btn-remove {
            background: red;
            color: white;
            border: none;
            padding: 7px 10px;
            cursor: pointer;
            border-radius: 5px;
        }
        .checkout-table {
            width: 50%;
            margin: 0 auto;
        }
        .checkout-table th {
            background:rgb(255,62,183);
            color: white;
        }
        .checkout-table td {
            text-align: left;
            padding: 10px;
        }
        .btn-checkout {
            background:rgb(255,62,183);
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
            width: 100%;
            margin-top: 10px;
        }
        .btn-checkout:hover {
            background:rgb(255,62,183);
        }
        input[type="checkbox"] {
            transform: scale(1.2);
        }  
        h2{
            padding-bottom : 20px;
            font-size: 30px;
        }
        h3{
            padding-bottom : 20px;
            font-size: 30px;
        }
        p{
            font-size: 20px;
        }
        /* Style for "Go back to shop" link */
        .back-to-shop {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #3498db;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .back-to-shop:hover {
            color: #2980b9;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Cart</h2>
    <div class="cart-table">
        <form method="POST" action="cart.php" id="cartForm">
            <table>
                <tr>
                    <th>Select</th>
                    <th>Image</th>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Remove</th>
                </tr>
                <?php
                foreach ($_SESSION['cart'] as $productId => $item):
                    $itemTotal = $item['product_price'] * $item['qty'];
                ?>
                <tr>
                    <td>
                        <input type="checkbox" name="selected_items[]" value="<?= htmlspecialchars($productId) ?>" class="item-checkbox" data-price="<?= $itemTotal ?>" data-qty="<?= $item['qty'] ?>" checked>
                    </td>
                    <td><img class="cart-image" src="<?= htmlspecialchars('../product_images/' . $item['product_image1']) ?>"></td>
                    <td><?= htmlspecialchars($item['product_name']) ?></td>
                    <td>₹<?= number_format($item['product_price'], 2) ?></td>
                    <td>
                        <div class="quantity-controls">
                            <button type="submit" name="decrease_quantity" value="<?= htmlspecialchars($productId) ?>">-</button>
                            <span><?= htmlspecialchars($item['qty']) ?></span>
                            <button type="submit" name="increase_quantity" value="<?= htmlspecialchars($productId) ?>">+</button>
                        </div>
                    </td>
                    <td class="item-total">₹<?= number_format($itemTotal, 2) ?></td>
                    <td>
                        <button type="submit" class="btn-remove" name="remove_item" value="<?= htmlspecialchars($productId) ?>">X</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </form>
        
        <br><br>

        <!-- Checkout Section -->
        <div class="checkout-box">
            <h3>Checkout</h3>
            <form method="POST" action="checkout.php">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required><br><br>
            
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required><br><br>

                  <label for="phone">Phone:</label>
                <input type="text" id="phone_no" name="phone_no" required><br><br>

                 <label for="address">Address:</label>
                <input type="text" id="address" name="address" required><br><br>
            
                <p>Subtotal: Rs. <span id="subtotal"><?= number_format($subtotal, 2) ?></span></p>
                <p>Shipping: Rs. 70</p>
                <p>VAT (13%): Rs. <span id="vat"><?= number_format($vat, 2) ?></span></p>
                <p>-----------------------------------</p>
                <p><strong>Total: Rs. <span id="total"><?= number_format($total, 2) ?></span></strong></p><br><br>
            
                <input type="hidden" name="subtotal" value="<?= $subtotal ?>">
                <input type="hidden" name="shipping" value="<?= $shipping ?>">
                <input type="hidden" name="vat" value="<?= $vat ?>">
                <input type="hidden" name="total" value="<?= $total ?>">
         <input type="hidden" name="product_image1" value="<?= htmlspecialchars($productImage) ?>">
                <button type="submit" class="btn-checkout">Proceed to Checkout</button>
            </form>
        </div>
        <a href="shop.php" class="back-to-shop">← Go back to shop</a>
    </div>
</div>

<script>
function updateTotal() {
    let checkboxes = document.querySelectorAll('.item-checkbox:checked');
    let subtotal = 0;
    
    checkboxes.forEach(checkbox => {
        subtotal += parseFloat(checkbox.getAttribute('data-price'));
    });

    let vat = subtotal * 0.13;
    let total = subtotal + 70 + vat;

    document.getElementById('subtotal').innerText = subtotal.toFixed(2);
    document.getElementById('vat').innerText = vat.toFixed(2);
    document.getElementById('total').innerText = total.toFixed(2);
}

// Update total when checkboxes are clicked
document.querySelectorAll('.item-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', updateTotal);
});

// Initialize total on page load
updateTotal();
</script>
</body>
</html>