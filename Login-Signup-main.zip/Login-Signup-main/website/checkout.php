<?php
session_start();

// Check if required data is present in the POST request
if (!isset($_POST['total'], $_POST['subtotal'], $_POST['shipping'], $_POST['vat'], $_POST['name'], $_POST['email'], $_POST['phone_no'], $_POST['address'], $_POST['product_image1'])) {
    header("Location: cart.php");
    exit();
}

// Retrieve order details from POST and sanitize (important!)
$total = filter_var($_POST['total'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
$subtotal = filter_var($_POST['subtotal'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
$shipping = filter_var($_POST['shipping'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
$vat = filter_var($_POST['vat'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
$name = filter_var($_POST['name'], FILTER_SANITIZE_STRING); // Basic sanitization for names
$email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL); // Sanitize email
$phone_no = filter_var($_POST['phone_no'], FILTER_SANITIZE_STRING); // Sanitize phone
$address = filter_var($_POST['address'], FILTER_SANITIZE_STRING); // Sanitize address
$product_image1 = filter_var($_POST['product_image1'], FILTER_SANITIZE_STRING);

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_db";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare SQL statement to insert order details
    $stmt = $conn->prepare("INSERT INTO orders (name, email, subtotal, shipping, vat, phone_no, address, total, product_image1)
                             VALUES (:name, :email, :subtotal, :shipping, :vat, :phone_no, :address, :total, :product_image1)");

    // Bind parameters
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':subtotal', $subtotal);
    $stmt->bindParam(':shipping', $shipping);
    $stmt->bindParam(':vat', $vat);
    $stmt->bindParam(':phone_no', $phone_no);
    $stmt->bindParam(':address', $address);
    $stmt->bindParam(':total', $total);
     $stmt->bindParam(':product_image1', $product_image1);

    // Execute the statement
    $stmt->execute();

    // Get the order ID
    $order_id = $conn->lastInsertId();
    echo "New record created successfully. Last inserted ID is: " . $order_id;

} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// Clear the cart after checkout
unset($_SESSION['cart']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Successful</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7f7f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 80%;
            max-width: 500px;
        }
        .checkmark-circle {
            width: 100px;
            height: 100px;
            background-color: #e8f5e9;
            border-radius: 50%;
            margin: 0 auto 30px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .checkmark {
            border-radius: 50%;
            display: block;
            stroke-width: 5;
            stroke: #4caf50;
            stroke-miterlimit: 10;
            box-shadow: inset 0px 0px 0px 10px #4caf50;
            animation: fill .4s ease-in-out .4s forwards, scale .3s ease-in-out .9s both;
        }
        @keyframes fill {
            100% {
                box-shadow: inset 0px 0px 0px 100px #4caf50;
            }
        }
        @keyframes scale {
            0%, 100% {
                transform: none;
            }
            50% {
                transform: scale3d(1.1, 1.1, 1);
            }
        }
        h1 {
            color: #333;
            margin-bottom: 10px;
        }
        p {
            color: #666;
            font-size: 1.1em;
            margin-bottom: 30px;
        }
        .done-button {
            background-color: #3498db;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s ease;
            text-decoration: none; /* Ensures the button isn't underlined if used as a link */
        }
        .done-button:hover {
            background-color: #2980b9;
        }

        .checkout-details p {
            margin: 5px 0; /* Adjust spacing as needed */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="checkmark-circle">
            <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
                <circle class="checkmark__circle" cx="26" cy="26" r="25" fill="none"/>
                <path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/>
            </svg>
        </div>
        <h1>Check-out Successful</h1>
        <p>Thank you, please visit again.</p>
        
        <div class="checkout-details">
            <p>Name: <?= htmlspecialchars($name) ?></p>
            <p>Email: <?= htmlspecialchars($email) ?></p>
            <p>Phone: <?= htmlspecialchars($phone_no) ?></p>
            <p>Address: <?= htmlspecialchars($address) ?></p>
            <p>Subtotal: Rs. <?= htmlspecialchars($subtotal) ?></p>
            <p>Shipping: Rs. <?= htmlspecialchars($shipping) ?></p>
            <p>VAT (13%): Rs. <?= htmlspecialchars($vat) ?></p>
            <p>Total: Rs. <?= htmlspecialchars($total) ?></p>
        </div><br>
        <a href="cart.php" class="done-button">Done</a>
    </div>
</body>
</html>