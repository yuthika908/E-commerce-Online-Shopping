<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: ./login.php");
    exit();
}

// Check if the success message is set
if (!isset($_SESSION['alert_message'])) {
    header("Location: ./index.php");
    exit();
}

$alert_message = $_SESSION['alert_message'];
$order_no = $_SESSION['order_no'] ?? 'Unknown';

// Unset the success message
unset($_SESSION['alert_message']);
unset($_SESSION['order_no']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Successful</title>
    <!-- Favicon Link -->
    <link rel="shortcut icon" href="./assets/images/favicon/favicon.ico" type="image/x-icon">
    <!-- External CSS Link -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <!-- responsive CSS Link -->
    <link rel="stylesheet" href="./assets/css/responsive.css">
    <!-- Font Awesome CSS Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <!-- Success Message -->
    <div class="success-container">
        <div class="success-message">
            <h2><?php echo htmlspecialchars($alert_message); ?></h2>
            <p>Thank you for your order!</p>
            <p>Your order number is: <strong><?php echo htmlspecialchars($order_no); ?></strong></p>
            <a href="./my_orders.php">View Orders</a>
            <a href="./index.php">Continue Shopping</a>
        </div>
    </div>

    <!-- Footer -->
    <?php include './includes/footer.php'; ?>
</body>

</html>