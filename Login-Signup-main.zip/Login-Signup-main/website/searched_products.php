<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fashion Hub - Search</title>
    <!-- Favicon Link -->
    <link rel="shortcut icon" href="../assets/images/favicon/favicon.ico" type="image/x-icon">
    <!-- External CSS Link -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- responsive CSS Link -->
    <link rel="stylesheet" href="../assets/css/responsive.css">
    <!-- Font Awesome Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body id="body">
    <!-- Server Error -->
    <?php
        include '../includes/check_connection.php';

        if (!isConnected()) {
            include '../includes/server_error.php';
            exit();
        }
    ?>
   

    <?php
        include '../includes/warning.php';
    ?>

    <!-- Header -->
    <?php include '../includes/header.php'; ?>

    <!-- Searched Products -->
    <section class="products-section">
        <!-- Product Box -->
        <?php 
            include '../Classes/database.php';
            include '../Classes/fetch.php';

            $fetch = new Fetch();

            $search = strtolower($_GET['search_data_query']);

            // Mapping search terms to specific categories
            $categoryMap = [
                'men' => 'T-Shirt',  // Display T-Shirts when "men" is searched
                'bag' => 'Bag Women', // Display Bag Women when "bag" is searched
                'womens' => 'Lehenga', // Display Lehenga when "womens" is searched
                'shoes' => 'Shoes', // Display Shoes when "shoes" is searched
                'cap' => 'Cap' // Display Cap when "cap" is searched
            ];

            // Use category map to get the mapped category
            $searchCategory = $categoryMap[$search] ?? $search;  // If search term not in map, use original term

            $records = $fetch->searched_products($searchCategory);

            $category = $fetch->get_category_array();

            $num_of_records = $records->rowCount();

            if ($num_of_records >= 1) {
                echo '<div class="search-results">
                        <h1>Results Related to : '. htmlspecialchars($search) .'</h1>
                </div>';
                echo '<div class="product-container">';
                while ($row = $records->fetch(PDO::FETCH_ASSOC)) {
                    echo '<div class="product-box show-all-product">
                    <a href="../product_details.php?product_id='.$row['product_id'].'">
                        <img src="../product_images/'. htmlspecialchars($row['product_image1']) .'">
                        <div class="product-desc">
                            <h4>'. htmlspecialchars($category[$row['category_id']]) .'</h4>
                            <h2>'. htmlspecialchars(substr($row['product_name'], 0, 20)) .'...</h2>
                            <div class="product-rating">
                                <i class="fa-solid fa-star"></i>
                                <span>'. htmlspecialchars($row['product_rating']) .'</span>
                            </div>
                            <h3><i class="fa-solid fa-indian-rupee-sign"></i> '. htmlspecialchars($row['product_price']) .'</h3>
                        </div>
                    </a>';

                    if (!isset($_SESSION['loggedin'])) {
                        echo '<div class="product-actions">
                            
                        </div>';
                    } else {
                        if ($fetch->check_product_in_cart($row['product_id'])) {
                            echo '<div class="product-actions">
                               
                            </div>';
                        } else {
                            echo '<div class="product-actions">
                              
                            </div>';
                        }
                    }

                    echo '</div>';
                }
                echo '</div>';
                if ($num_of_records > 12) {
                    echo '<div class="show-more">
                        <span id="load-more">Load More</span>
                    </div>';
                }
            } else {
                echo '<div class="no-product-found">
                        <img src="../assets/images/Results/4.png"/>
                </div>';
            }  
        ?>
    </section>

    <!-- Footer -->
    <?php include '../includes/footer.php'; ?>

    <!-- External Js Links -->
    <script src="../assets/js/bars.js"></script>
    <script src="../assets/js/load_more.js"></script>
    <!-- Including Js Files only if necessary -->
    <?php
        if (!isset($_SESSION['loggedin'])) {
            echo '<script src="../assets/js/modal.js"></script>';
            echo '<script src="../assets/js/validate.js"></script>';
            echo '<script src="../assets/js/warning.js"></script>';
        }
    ?>
</body>

</html>